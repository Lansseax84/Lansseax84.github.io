#!/bin/bash
# ghost-rescue.sh — GHOST EYES
# Ejecutar desde TTY (Ctrl+Alt+F3) cuando el GUI no arranca
# Uso: sudo bash ghost-rescue.sh

O="\033[38;5;166m"; OG="\033[38;5;208m"; OD="\033[38;5;130m"
GR="\033[38;5;64m"; R="\033[38;5;160m"; Y="\033[38;5;136m"
GREY="\033[38;5;238m"; RESET="\033[0m"; BOLD="\033[1m"

log() { echo -e "${O}[rescue]${RESET} $*"; }
ok()  { echo -e "  ${GR}✓${RESET} $*"; }
warn(){ echo -e "  ${Y}⚠${RESET} $*"; }

echo -e "\n${O}  GHOST EYES · MODO RESCATE${RESET}\n"
echo -e "  ${OD}Diagnóstico de por qué no arranca el GUI...${RESET}\n"

# ── Diagnosis ─────────────────────────────────────────────
echo -e "${O}── KERNEL Y MÓDULOS ────────────────────────────────${RESET}"
echo -e "  Kernel: $(uname -r)"
echo -e "  nvidia cargado: $(lsmod | grep "^nvidia " | wc -l) módulos"
echo -e "  nouveau: $(lsmod | grep nouveau | wc -l) módulos"
echo ""

echo -e "${O}── DKMS STATUS ─────────────────────────────────────${RESET}"
dkms status 2>/dev/null | head -10 || echo "  dkms no disponible"
echo ""

echo -e "${O}── DISPLAY MANAGER ─────────────────────────────────${RESET}"
echo -e "  target: $(systemctl get-default 2>/dev/null)"
echo -e "  lightdm enabled: $(systemctl is-enabled lightdm 2>/dev/null)"
echo -e "  lightdm active: $(systemctl is-active lightdm 2>/dev/null)"
echo ""

echo -e "${O}── ÚLTIMOS ERRORES NVIDIA / DRM ────────────────────${RESET}"
journalctl -b --no-pager | grep -iE "nvidia|NVRM|drm|lightdm|xorg" | tail -20 2>/dev/null
echo ""

echo -e "${O}── ACCIONES RÁPIDAS ─────────────────────────────────${RESET}"
echo ""
echo -e "  ${OG}1${RESET}) Reconstruir DKMS para kernel actual"
echo -e "  ${OG}2${RESET}) Forzar inicio de LightDM ahora"
echo -e "  ${OG}3${RESET}) Establecer graphical.target + habilitar LightDM"
echo -e "  ${OG}4${RESET}) Eliminar xorg.conf corrupto"
echo -e "  ${OG}5${RESET}) Ver log completo de errores"
echo -e "  ${OG}6${RESET}) Ejecutar ghost-nvidia-kali.sh completo"
echo -e "  ${OG}q${RESET}) Salir"
echo ""
echo -e "  ${OD}Elige opción: ${RESET}"
read -r opt

case "$opt" in
  1)
    log "Reconstruyendo DKMS..."
    NEWK=$(ls -1 /lib/modules 2>/dev/null | sort -V | tail -1)
    apt-get install -y "linux-headers-$NEWK" 2>/dev/null || true
    dkms autoinstall -k "$NEWK"
    update-initramfs -u -k all
    ok "Hecho. Reinicia."
    ;;
  2)
    log "Iniciando LightDM..."
    systemctl start lightdm
    ;;
  3)
    log "Configurando systemd..."
    systemctl set-default graphical.target
    systemctl enable lightdm
    ok "Hecho. Reinicia."
    ;;
  4)
    log "Eliminando xorg.conf..."
    rm -f /etc/X11/xorg.conf && ok "Eliminado." || warn "No existía."
    ;;
  5)
    journalctl -b --no-pager | grep -iE "nvidia|NVRM|drm|lightdm|xorg|error|fail" | less
    ;;
  6)
    if [ -f /usr/local/bin/ghost-nvidia-kali ]; then
      bash /usr/local/bin/ghost-nvidia-kali
    else
      warn "ghost-nvidia-kali no instalado. Ejecuta desde el directorio del proyecto."
    fi
    ;;
  q|Q)
    exit 0
    ;;
esac
