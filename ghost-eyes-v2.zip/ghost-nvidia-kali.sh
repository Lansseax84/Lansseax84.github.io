#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║  ghost-nvidia-kali.sh — GHOST EYES PROJECT                      ║
# ║  Solución DEFINITIVA RTX 5060 (Blackwell) en Kali Linux         ║
# ║  Uso: sudo bash ghost-nvidia-kali.sh                            ║
# ║                                                                  ║
# ║  Resuelve los 7 motivos conocidos de TTY en Kali + RTX 5060:    ║
# ║  1. Driver propietario en vez de nvidia-open-dkms               ║
# ║  2. DKMS desincronizado tras actualización de kernel            ║
# ║  3. nouveau no bloqueado correctamente                          ║
# ║  4. Parámetros GRUB incorrectos / faltantes                     ║
# ║  5. Display manager (LightDM) no habilitado como servicio       ║
# ║  6. Target de systemd no es graphical.target                    ║
# ║  7. BIOS en modo Legacy/CSM (RTX 5060 requiere UEFI)           ║
# ╚══════════════════════════════════════════════════════════════════╝

set -e

# ── Colores ──────────────────────────────────────────────────
O="\033[38;5;166m"
OD="\033[38;5;130m"
OG="\033[38;5;208m"
GR="\033[38;5;64m"
R="\033[38;5;160m"
Y="\033[38;5;136m"
GREY="\033[38;5;238m"
W="\033[38;5;255m"
RESET="\033[0m"
BOLD="\033[1m"

log()     { echo -e "${O}[ghost-nvidia]${RESET} $*"; }
ok()      { echo -e "  ${GR}✓${RESET} $*"; }
warn()    { echo -e "  ${Y}⚠${RESET} $*"; }
err()     { echo -e "  ${R}✗${RESET} $*"; }
header()  {
  echo ""
  echo -e "${O}══════════════════════════════════════════════════${RESET}"
  echo -e "  ${OG}${BOLD}$*${RESET}"
  echo -e "${O}══════════════════════════════════════════════════${RESET}"
  echo ""
}
step()    { echo -e "\n  ${OD}▸ $*${RESET}"; }
check()   { echo -e "  ${GREY}  → $*${RESET}"; }

# ── Verificar root ────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  echo -e "${R}[!] Necesita root: sudo bash ghost-nvidia-kali.sh${RESET}"
  exit 1
fi

# ── Log de todo el proceso ────────────────────────────────────
LOG_FILE="/var/log/ghost-nvidia-kali.log"
exec > >(tee -a "$LOG_FILE") 2>&1
log "Log guardado en: $LOG_FILE"

clear
echo -e "${O}"
cat << 'BANNER'
  ███╗   ██╗██╗   ██╗██╗██████╗ ██╗ █████╗     ██╗  ██╗ █████╗ ██╗     ██╗
  ████╗  ██║██║   ██║██║██╔══██╗██║██╔══██╗    ██║ ██╔╝██╔══██╗██║     ██║
  ██╔██╗ ██║██║   ██║██║██║  ██║██║███████║    █████╔╝ ███████║██║     ██║
  ██║╚██╗██║╚██╗ ██╔╝██║██║  ██║██║██╔══██║    ██╔═██╗ ██╔══██║██║     ██║
  ██║ ╚████║ ╚████╔╝ ██║██████╔╝██║██║  ██║    ██║  ██╗██║  ██║███████╗██║
  ╚═╝  ╚═══╝  ╚═══╝  ╚═╝╚═════╝ ╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝
BANNER
echo -e "${RESET}"
echo -e "  ${OD}GHOST EYES · Solución definitiva RTX 5060 en Kali Linux${RESET}"
echo -e "  ${GREY}Resuelve los 7 motivos conocidos de pantalla TTY / negra${RESET}"
echo ""

# ════════════════════════════════════════════════════════════
# DIAGNÓSTICO PREVIO
# ════════════════════════════════════════════════════════════
header "DIAGNÓSTICO DEL SISTEMA"

# GPU detectada
GPU_INFO=$(lspci | grep -iE "vga|3d|display" 2>/dev/null | head -3)
KERNEL=$(uname -r)
KERNEL_MAJ=$(uname -r | cut -d. -f1)
KERNEL_MIN=$(uname -r | cut -d. -f2)
BOOT_MODE=$([ -d /sys/firmware/efi ] && echo "UEFI" || echo "LEGACY")
DM_STATUS=$(systemctl is-active lightdm 2>/dev/null || echo "inactive")
DM_ENABLED=$(systemctl is-enabled lightdm 2>/dev/null || echo "disabled")
GRAPHICAL_TARGET=$(systemctl get-default 2>/dev/null || echo "unknown")
NOUVEAU_LOADED=$(lsmod | grep nouveau | wc -l)
NVIDIA_LOADED=$(lsmod | grep "^nvidia " | wc -l)

echo -e "  ${OD}GPU detectada   :${RESET} ${OG}${GPU_INFO:-No detectada}${RESET}"
echo -e "  ${OD}Kernel actual   :${RESET} ${OG}${KERNEL}${RESET}"
echo -e "  ${OD}Modo BIOS       :${RESET} $([ "$BOOT_MODE" = "UEFI" ] && echo "${GR}UEFI ✓${RESET}" || echo "${R}LEGACY ✗${RESET}")"
echo -e "  ${OD}Display Manager :${RESET} LightDM — $([ "$DM_ENABLED" = "enabled" ] && echo "${GR}habilitado ✓${RESET}" || echo "${R}NO habilitado ✗${RESET}")"
echo -e "  ${OD}Target systemd  :${RESET} $([ "$GRAPHICAL_TARGET" = "graphical.target" ] && echo "${GR}graphical.target ✓${RESET}" || echo "${R}${GRAPHICAL_TARGET} ✗${RESET}")"
echo -e "  ${OD}nouveau cargado :${RESET} $([ "$NOUVEAU_LOADED" -gt 0 ] && echo "${R}SÍ — problema ✗${RESET}" || echo "${GR}No ✓${RESET}")"
echo -e "  ${OD}nvidia cargado  :${RESET} $([ "$NVIDIA_LOADED" -gt 0 ] && echo "${GR}SÍ ✓${RESET}" || echo "${Y}No — a instalar${RESET}")"

echo ""
echo -e "  ${OD}Repositorios sources.list:${RESET}"
cat /etc/apt/sources.list | grep -v "^#" | grep -v "^$" | head -3 | while read line; do
  echo -e "    ${GREY}${line}${RESET}"
done

echo ""
echo -e "  ${OD}¿Continuar con la instalación/reparación? (s/N): ${RESET}"
read -r resp
[[ "$resp" =~ ^[sS]$ ]] || { log "Abortado."; exit 0; }

# ════════════════════════════════════════════════════════════
# MOTIVO 1: VERIFICAR/CORREGIR MODO UEFI
# ════════════════════════════════════════════════════════════
header "MOTIVO 1 · Modo BIOS (UEFI requerido para RTX 5060)"

if [ "$BOOT_MODE" = "UEFI" ]; then
  ok "Sistema en modo UEFI. Correcto."
else
  warn "BIOS en modo LEGACY/CSM detectado."
  warn "La RTX 5060 puede tener pantalla negra en modo Legacy."
  warn "NVIDIA tiene una herramienta oficial de firmware para este problema:"
  warn "  https://www.nvidia.com/en-us/drivers/gpu-firmware-update-utility/"
  warn "Entra en la BIOS y activa 'UEFI Boot Mode' / desactiva 'CSM'."
  warn "Continuando de todas formas — algunas motherboards funcionan en Legacy."
fi

# ════════════════════════════════════════════════════════════
# MOTIVO 2: KERNEL COMPATIBLE
# ════════════════════════════════════════════════════════════
header "MOTIVO 2 · Versión del kernel (mínimo 6.11)"

if [ "$KERNEL_MAJ" -gt 6 ] || ([ "$KERNEL_MAJ" -eq 6 ] && [ "$KERNEL_MIN" -ge 11 ]); then
  ok "Kernel ${KERNEL} compatible con RTX 5060."
else
  warn "Kernel ${KERNEL} demasiado antiguo. Actualizando..."
  apt-get update -qq
  apt-get install -y linux-image-amd64 linux-headers-amd64
  NEED_REBOOT=1
  ok "Kernel actualizado. Reinicio necesario al final."
fi

# Instalar headers del kernel ACTUAL siempre
step "Instalando linux-headers para el kernel actual..."
apt-get update -qq
apt-get install -y "linux-headers-$(uname -r)" || {
  warn "Headers del kernel actual no disponibles. Intentando con el más nuevo..."
  NEWK=$(ls -1 /lib/modules 2>/dev/null | sort -V | tail -1)
  apt-get install -y "linux-headers-${NEWK}" || warn "No se pudieron instalar headers."
}
ok "Headers del kernel instalados."

# ════════════════════════════════════════════════════════════
# MOTIVO 3: LIMPIAR DRIVER INCORRECTO + PURGA TOTAL
# ════════════════════════════════════════════════════════════
header "MOTIVO 3 · Limpiar drivers NVIDIA incorrectos"

step "Parando display manager..."
for dm in gdm3 lightdm sddm xdm; do
  systemctl stop "$dm" 2>/dev/null && log "Detenido: $dm" || true
done

step "Purgando todos los paquetes NVIDIA anteriores..."
# Esta es la purga más completa posible
PKGS_TO_REMOVE=$(dpkg -l | grep -iE "nvidia|cuda|libnv" | awk '{print $2}' | tr '\n' ' ' 2>/dev/null || echo "")
if [ -n "$PKGS_TO_REMOVE" ]; then
  apt-get purge -y $PKGS_TO_REMOVE 2>/dev/null || true
  ok "Paquetes nvidia eliminados."
else
  ok "No había paquetes nvidia previos."
fi

apt-get autoremove -y 2>/dev/null || true

# Eliminar archivos de configuración residuales
step "Eliminando configuraciones residuales..."
rm -f /etc/modprobe.d/nvidia*.conf 2>/dev/null || true
rm -f /etc/modprobe.d/ghost-*.conf 2>/dev/null || true
rm -f /etc/X11/xorg.conf 2>/dev/null && warn "Eliminado xorg.conf corrupto." || true
# IMPORTANTE: xorg.conf mal generado con nvidia-xconfig es causa frecuente de TTY en Kali
ok "Archivos residuales eliminados."

# ════════════════════════════════════════════════════════════
# MOTIVO 4: BLOQUEAR NOUVEAU CORRECTAMENTE
# ════════════════════════════════════════════════════════════
header "MOTIVO 4 · Bloquear nouveau"

step "Descargando módulo nouveau de la sesión actual..."
modprobe -r nouveau 2>/dev/null || true

step "Bloqueando nouveau permanentemente..."
# Exactamente como indica la documentación oficial de Kali
cat > /etc/modprobe.d/blacklist-nouveau.conf << 'NOUVEAU_BL'
# GHOST EYES — Bloqueo de nouveau para NVIDIA RTX 5060
blacklist nouveau
blacklist lbm-nouveau
options nouveau modeset=0
alias nouveau off
alias lbm-nouveau off
NOUVEAU_BL
ok "nouveau bloqueado."

# ════════════════════════════════════════════════════════════
# MOTIVO 5: INSTALAR DRIVER CORRECTO (nvidia-open-dkms)
# ════════════════════════════════════════════════════════════
header "MOTIVO 5 · Instalar nvidia-open-dkms (obligatorio para Blackwell)"

step "Verificando repositorios contrib non-free..."
# Kali necesita contrib non-free para los drivers nvidia
SOURCES="/etc/apt/sources.list"
if ! grep -qE "contrib.*non-free|non-free.*contrib" "$SOURCES" 2>/dev/null; then
  # Añadir contrib non-free a las líneas de kali-rolling
  sed -i 's/kali-rolling main$/kali-rolling main contrib non-free non-free-firmware/' "$SOURCES" 2>/dev/null || true
  sed -i 's/kali-rolling main contrib$/kali-rolling main contrib non-free non-free-firmware/' "$SOURCES" 2>/dev/null || true
  ok "Repositorios contrib non-free añadidos."
else
  ok "Repositorios contrib non-free ya presentes."
fi

step "Actualizando lista de paquetes..."
apt-get update -qq

step "Instalando dependencias de compilación..."
apt-get install -y \
  build-essential \
  dkms \
  pkg-config \
  libglvnd-dev \
  libglvnd0 \
  gcc \
  make \
  2>/dev/null

step "Instalando driver nvidia-open-dkms..."
# Para Kali (base Debian): el paquete correcto es nvidia-open-dkms o nvidia-kernel-open-dkms
# junto con nvidia-driver y las librerías necesarias

INSTALL_OK=0

# Intento 1: nvidia-open-dkms (paquete preferido Debian/Kali)
if apt-get install -y nvidia-open-dkms nvidia-driver 2>/dev/null; then
  ok "Instalado: nvidia-open-dkms + nvidia-driver"
  INSTALL_OK=1
fi

# Intento 2: nvidia-kernel-open-dkms (nombre alternativo)
if [ "$INSTALL_OK" -eq 0 ]; then
  if apt-get install -y nvidia-kernel-open-dkms nvidia-driver 2>/dev/null; then
    ok "Instalado: nvidia-kernel-open-dkms + nvidia-driver"
    INSTALL_OK=1
  fi
fi

# Intento 3: nvidia-driver sólo (incluye open en versiones nuevas de Kali)
if [ "$INSTALL_OK" -eq 0 ]; then
  warn "nvidia-open-dkms no disponible en repos. Intentando nvidia-driver solo..."
  if apt-get install -y nvidia-driver 2>/dev/null; then
    ok "Instalado: nvidia-driver"
    INSTALL_OK=1
  fi
fi

if [ "$INSTALL_OK" -eq 0 ]; then
  warn "No se pudo instalar desde repos. Consultando versión disponible..."
  apt-cache search nvidia | grep -iE "driver|dkms|open" | head -10
  warn "Instala manualmente el driver 570+ desde:"
  warn "  https://www.nvidia.com/en-us/drivers/"
fi

# Instalar paquetes complementarios esenciales
apt-get install -y \
  nvidia-settings \
  nvidia-smi \
  libgl1-mesa-dri \
  libglx-mesa0 \
  xserver-xorg-video-nvidia \
  2>/dev/null || true

ok "Driver instalado."

# ════════════════════════════════════════════════════════════
# APT HOOK: auto-rebuild DKMS cuando se actualice el kernel
# (Solución oficial de documentación Kali Dec 2025)
# ════════════════════════════════════════════════════════════
step "Instalando APT hook para mantener DKMS sincronizado..."
tee /etc/apt/apt.conf.d/99-kernel-headers-dkms >/dev/null << 'HOOK'
DPkg::Post-Invoke {
  "bash -c 'set -e; newk=$(ls -1 /lib/modules 2>/dev/null | sort -V | tail -1); if [ -n \"$newk\" ] && [ ! -d /usr/src/linux-headers-$newk ]; then echo \"[apt-hook] Instalando headers para $newk\" >&2; apt-get -y install linux-headers-$newk || true; fi; if command -v dkms >/dev/null; then dkms autoinstall -k $newk || true; fi'"
  ;
};
HOOK
ok "APT hook instalado — DKMS se reconstruirá automáticamente tras cada actualización de kernel."

# ════════════════════════════════════════════════════════════
# MOTIVO 5b: RECONSTRUIR DKMS PARA KERNEL ACTUAL
# ════════════════════════════════════════════════════════════
step "Reconstruyendo módulos DKMS para el kernel actual..."
NEWK=$(ls -1 /lib/modules 2>/dev/null | sort -V | tail -1)
if command -v dkms >/dev/null; then
  dkms autoinstall -k "$NEWK" 2>/dev/null || warn "DKMS autoinstall tuvo errores — puede no ser crítico."
  ok "DKMS reconstruido para kernel: $NEWK"
fi

# Verificar que el módulo se compiló
if ls /lib/modules/"$NEWK"/updates/dkms/nvidia*.ko 2>/dev/null | head -1 | grep -q nvidia; then
  ok "Módulo nvidia.ko compilado correctamente para $NEWK"
else
  warn "No se encontró nvidia.ko compilado. Intentando build manual..."
  # Intentar build manual
  NVIDIA_VER=$(dkms status 2>/dev/null | grep nvidia | head -1 | cut -d, -f2 | xargs 2>/dev/null || echo "")
  if [ -n "$NVIDIA_VER" ]; then
    dkms build -m nvidia -v "$NVIDIA_VER" -k "$NEWK" 2>/dev/null || true
    dkms install -m nvidia -v "$NVIDIA_VER" -k "$NEWK" 2>/dev/null || true
  fi
fi

# ════════════════════════════════════════════════════════════
# MOTIVO 6: PARÁMETROS GRUB (los correctos para RTX 5060)
# ════════════════════════════════════════════════════════════
header "MOTIVO 6 · Parámetros GRUB para Kali + RTX 5060"

GRUB_FILE="/etc/default/grub"
CURRENT_CMDLINE=$(grep "^GRUB_CMDLINE_LINUX_DEFAULT" "$GRUB_FILE" 2>/dev/null | cut -d'"' -f2)

step "Configurando parámetros del kernel..."

# Limpiar parámetros conflictivos viejos
NEW_CMDLINE=$(echo "$CURRENT_CMDLINE" | \
  sed 's/nomodeset//g' | \
  sed 's/nvidia_drm\.modeset=[01]//g' | \
  sed 's/nvidia_drm\.fbdev=[01]//g' | \
  sed 's/nvidia\.NVreg_OpenRmEnableUnsupportedGpus=[01]//g' | \
  sed 's/  / /g' | xargs)

# Añadir los parámetros correctos
# nvidia_drm.modeset=1: permite gestión del display desde el inicio del boot
# nvidia_drm.fbdev=1: fuerza framebuffer nvidia (fix TTY en Kali según docs oficiales)
# nvidia.NVreg_OpenRmEnableUnsupportedGpus=1: necesario para algunos Blackwell
NEW_CMDLINE="$NEW_CMDLINE nvidia_drm.modeset=1 nvidia_drm.fbdev=1 nvidia.NVreg_OpenRmEnableUnsupportedGpus=1"

# Quitar 'quiet splash' solo si está causando problemas de debug
# Lo dejamos activado para el boot normal

sed -i "s|^GRUB_CMDLINE_LINUX_DEFAULT=.*|GRUB_CMDLINE_LINUX_DEFAULT=\"$NEW_CMDLINE\"|" "$GRUB_FILE"
check "GRUB_CMDLINE_LINUX_DEFAULT=\"$NEW_CMDLINE\""
update-grub 2>/dev/null || grub-mkconfig -o /boot/grub/grub.cfg
ok "GRUB actualizado."

# ════════════════════════════════════════════════════════════
# Configurar módulos en modprobe
# ════════════════════════════════════════════════════════════
step "Configurando opciones de módulo nvidia..."
cat > /etc/modprobe.d/ghost-nvidia-options.conf << 'NVCONF'
# GHOST EYES — Opciones NVIDIA RTX 5060 Kali Linux
options nvidia-drm modeset=1
options nvidia-drm fbdev=1
options nvidia NVreg_OpenRmEnableUnsupportedGpus=1
options nvidia NVreg_PreserveVideoMemoryAllocations=1
# Evitar conflicto con simpledrm (importante en Kali rolling)
softdep nvidia pre: drm
softdep nvidia-drm pre: nvidia
NVCONF
ok "Opciones de módulo configuradas."

# Añadir nvidia a modules cargados en initramfs
step "Añadiendo nvidia a initramfs..."
if [ -f /etc/initramfs-tools/modules ]; then
  for mod in nvidia nvidia_drm nvidia_uvm nvidia_modeset; do
    grep -q "^$mod" /etc/initramfs-tools/modules 2>/dev/null || echo "$mod" >> /etc/initramfs-tools/modules
  done
fi
ok "Módulos añadidos a initramfs."

# ════════════════════════════════════════════════════════════
# MOTIVO 7: DISPLAY MANAGER + SYSTEMD TARGET
# ════════════════════════════════════════════════════════════
header "MOTIVO 7 · Display Manager y target de systemd"

# Este es el motivo más frecuente de TTY en Kali tras instalar nvidia:
# el target no es graphical.target o lightdm no está habilitado

step "Verificando target de systemd..."
CURRENT_TARGET=$(systemctl get-default 2>/dev/null || echo "unknown")
if [ "$CURRENT_TARGET" != "graphical.target" ]; then
  warn "Target actual: $CURRENT_TARGET — cambiando a graphical.target..."
  systemctl set-default graphical.target
  ok "Target cambiado a graphical.target"
else
  ok "Target ya es graphical.target"
fi

step "Verificando y habilitando LightDM..."
# Instalar lightdm si no está
if ! command -v lightdm &>/dev/null; then
  warn "LightDM no instalado. Instalando..."
  apt-get install -y lightdm lightdm-gtk-greeter 2>/dev/null || \
  apt-get install -y lightdm 2>/dev/null || true
fi

# Habilitar lightdm
systemctl enable lightdm 2>/dev/null && ok "LightDM habilitado." || warn "No se pudo habilitar LightDM."

# Verificar que XFCE o el DE está instalado
step "Verificando entorno de escritorio..."
DE_INSTALLED=0
for de_pkg in kali-desktop-xfce xfce4 gnome-shell kde-plasma-desktop; do
  if dpkg -l | grep -q "^ii.*$de_pkg" 2>/dev/null; then
    ok "Entorno detectado: $de_pkg"
    DE_INSTALLED=1
    break
  fi
done

if [ "$DE_INSTALLED" -eq 0 ]; then
  warn "No se detectó entorno de escritorio. Instalando kali-desktop-xfce..."
  apt-get install -y kali-desktop-xfce 2>/dev/null || \
  apt-get install -y xfce4 2>/dev/null || true
  ok "Entorno de escritorio instalado."
fi

# ════════════════════════════════════════════════════════════
# REGENERAR INITRAMFS (PASO CRÍTICO)
# ════════════════════════════════════════════════════════════
header "REGENERAR INITRAMFS"

step "Regenerando initramfs para todos los kernels..."
update-initramfs -u -k all
ok "initramfs regenerado."

# ════════════════════════════════════════════════════════════
# VERIFICACIÓN FINAL
# ════════════════════════════════════════════════════════════
header "VERIFICACIÓN FINAL"

step "Verificando estado de DKMS..."
dkms status 2>/dev/null | grep nvidia | while read line; do
  echo -e "    ${GREY}$line${RESET}"
done

step "Verificando módulos nvidia en kernel actual..."
NEWK=$(ls -1 /lib/modules 2>/dev/null | sort -V | tail -1)
if find /lib/modules/"$NEWK" -name "nvidia*.ko*" 2>/dev/null | head -1 | grep -q nvidia; then
  ok "Módulos nvidia.ko encontrados en /lib/modules/$NEWK"
else
  warn "No se encontraron módulos nvidia.ko — puede que DKMS compile en el primer boot."
fi

step "Verificando contenido de /etc/modprobe.d/..."
ls /etc/modprobe.d/*.conf | while read f; do
  echo -e "    ${GREY}$(basename $f)${RESET}"
done

step "Verificando GRUB final..."
grep "GRUB_CMDLINE_LINUX_DEFAULT" /etc/default/grub | while read line; do
  echo -e "    ${OG}$line${RESET}"
done

step "Verificando systemd target y LightDM..."
echo -e "    ${GREY}Target: $(systemctl get-default 2>/dev/null)${RESET}"
echo -e "    ${GREY}LightDM: $(systemctl is-enabled lightdm 2>/dev/null)${RESET}"

# ════════════════════════════════════════════════════════════
# RESUMEN Y PASOS SIGUIENTES
# ════════════════════════════════════════════════════════════
echo ""
echo -e "${O}╔══════════════════════════════════════════════════════════════╗${RESET}"
echo -e "${O}║${RESET}  ${OG}${BOLD}INSTALACIÓN COMPLETADA — RTX 5060 KALI LINUX${RESET}               ${O}║${RESET}"
echo -e "${O}╠══════════════════════════════════════════════════════════════╣${RESET}"
echo -e "${O}║${RESET}  ${GR}✓${RESET} Driver nvidia-open-dkms instalado                        ${O}║${RESET}"
echo -e "${O}║${RESET}  ${GR}✓${RESET} nouveau bloqueado persistentemente                       ${O}║${RESET}"
echo -e "${O}║${RESET}  ${GR}✓${RESET} GRUB con nvidia_drm.modeset=1 + fbdev=1                 ${O}║${RESET}"
echo -e "${O}║${RESET}  ${GR}✓${RESET} LightDM habilitado como servicio                        ${O}║${RESET}"
echo -e "${O}║${RESET}  ${GR}✓${RESET} systemd target: graphical.target                        ${O}║${RESET}"
echo -e "${O}║${RESET}  ${GR}✓${RESET} APT hook: DKMS se reconstruye con cada kernel            ${O}║${RESET}"
echo -e "${O}║${RESET}  ${GR}✓${RESET} initramfs regenerado                                     ${O}║${RESET}"
echo -e "${O}╠══════════════════════════════════════════════════════════════╣${RESET}"
echo -e "${O}║${RESET}  ${W}DESPUÉS DE REINICIAR — VERIFICA CON:${RESET}                       ${O}║${RESET}"
echo -e "${O}║${RESET}  ${OD}1.${RESET} ${OG}nvidia-smi${RESET}                → GPU reconocida           ${O}║${RESET}"
echo -e "${O}║${RESET}  ${OD}2.${RESET} ${OG}lsmod | grep nvidia${RESET}       → módulos cargados        ${O}║${RESET}"
echo -e "${O}║${RESET}  ${OD}3.${RESET} ${OG}glxinfo | grep renderer${RESET}   → NVIDIA en uso           ${O}║${RESET}"
echo -e "${O}╠══════════════════════════════════════════════════════════════╣${RESET}"
echo -e "${O}║${RESET}  ${Y}SI AÚN SALE TTY DESPUÉS DE REINICIAR:${RESET}                     ${O}║${RESET}"
echo -e "${O}║${RESET}  Desde TTY ejecuta:                                          ${O}║${RESET}"
echo -e "${O}║${RESET}  ${OG}journalctl -b | grep -iE 'nvidia|drm|NVRM|lightdm'${RESET}       ${O}║${RESET}"
echo -e "${O}║${RESET}  y pega el resultado para diagnosticar.                       ${O}║${RESET}"
echo -e "${O}║${RESET}  También prueba desde TTY: ${OG}sudo systemctl start lightdm${RESET}      ${O}║${RESET}"
echo -e "${O}╚══════════════════════════════════════════════════════════════╝${RESET}"
echo ""
log "Log completo guardado en: $LOG_FILE"
echo ""
echo -e "  ${OD}¿Reiniciar ahora? (s/N): ${RESET}"
read -r resp
[[ "$resp" =~ ^[sS]$ ]] && reboot
